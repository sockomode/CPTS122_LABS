// Task1.cpp
#include "Task1.h"

void Base::testFunction()
{
    cout << "Base class" << endl;
}



void Derived::testFunction()
{
    cout << "Derived class" << endl;
}